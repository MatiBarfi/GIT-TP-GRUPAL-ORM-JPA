import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // 1. Iniciar el contenedor de JPA y obtener el EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            // 2. Iniciar la transacción
            em.getTransaction().begin();

            Date ahora = new Date();

            // 3. Instanciar y persistir las entidades maestras previas necesarias
            Usuario usuarioAdmin = Usuario.builder()
                    .usuario("admin")
                    .clave("123456")
                    .nombre("Juan")
                    .apellido("Pérez")
                    .build();
            em.persist(usuarioAdmin);

            PuntoVenta puntoVenta = PuntoVenta.builder()
                    .numero(1)
                    .descripcion("Punto de Venta Centro")
                    .tipoEmision("Factura Electrónica")
                    .domicilioComercial("Av. San Martín 1000")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(puntoVenta);

            Marca marca = Marca.builder()
                    .codigo(101)
                    .denominacion("Logitech")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(marca);

            Articulo articulo = Articulo.builder()
                    .codigo("ART-001")
                    .denominacion("Mouse Inalámbrico")
                    .marca(marca)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(articulo);

            ListaPrecio listaPrecio = ListaPrecio.builder()
                    .codigo("LP-MAY")
                    .denominacion("Lista Mayorista")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(listaPrecio);

            ListaPrecioArticulo listaPrecioArticulo = ListaPrecioArticulo.builder()
                    .listaPrecio(listaPrecio)
                    .articulo(articulo)
                    .precioVenta(15000.0)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(listaPrecioArticulo);

            // 4. Instanciar la cabecera FacturaVenta
            FacturaVenta factura = FacturaVenta.builder()
                    .numero(1001L)
                    .fechaEmision(ahora)
                    .puntoVenta(puntoVenta)
                    .importeCobrado(30000.0)
                    .importeSaldo(0.0)
                    .importeTotal(30000.0)
                    .cae("73428917238912")
                    .resultadoAfip("A")
                    .estado("Emitida")
                    .observaciones("Venta minorista de prueba")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .detalles(new ArrayList<>())
                    .build();

            // 5. Instanciar detalles y asociar bidireccionalmente
            FacturaVentaDetalle detalle1 = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(listaPrecioArticulo)
                    .descripcion("Mouse Inalámbrico - Unidad 1")
                    .cantidad(1.0)
                    .precioUnitario(15000.0)
                    .porcentajeBonificacion(0.0)
                    .importeNeto(12396.69)
                    .importeIva(2603.31)
                    .importeSubtotal(15000.0)
                    .factura(factura) // Relación hacia la cabecera
                    .build();

            FacturaVentaDetalle detalle2 = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(listaPrecioArticulo)
                    .descripcion("Mouse Inalámbrico - Unidad 2")
                    .cantidad(1.0)
                    .precioUnitario(15000.0)
                    .porcentajeBonificacion(0.0)
                    .importeNeto(12396.69)
                    .importeIva(2603.31)
                    .importeSubtotal(15000.0)
                    .factura(factura) // Relación hacia la cabecera
                    .build();

            factura.getDetalles().add(detalle1);
            factura.getDetalles().add(detalle2);

            // 6. Persistir ÚNICAMENTE la cabecera FacturaVenta
            em.persist(factura);

            // 7. Finalizar la transacción
            em.getTransaction().commit();
            System.out.println("\nFactura persistida con exito bajo el ID: " + factura.getId());
            System.out.println("Detalles persistidos por cascada: " + factura.getDetalles().size());

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // 8. Cerrar EntityManager y EntityManagerFactory
            em.close();
            emf.close();
        }
    }
}