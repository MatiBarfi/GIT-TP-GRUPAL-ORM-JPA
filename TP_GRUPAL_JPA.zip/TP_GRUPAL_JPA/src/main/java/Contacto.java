import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
public class Contacto extends EntityId {
    private String email;
    private String telefono;
    private String celular;
}
