import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Table
@SuperBuilder
@Getter
@Setter
class Articulo extends AuditoriaApp {
    @ManyToOne
    @JoinColumn(name = "id_rubro")
    private Rubro rubro;

    @Column(nullable = false)
    private String codigo;

    @Column(nullable = false)
    private String denominacion;

    @ManyToOne
    @JoinColumn(name = "id_marca")
    private Marca marca;
}