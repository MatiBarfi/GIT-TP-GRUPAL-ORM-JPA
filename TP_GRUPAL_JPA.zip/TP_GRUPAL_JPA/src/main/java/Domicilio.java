import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
@SuperBuilder
@Getter
@Setter
public class Domicilio extends EntityId {
    private String nombreCalle;
    private String numeroCalle;
}
