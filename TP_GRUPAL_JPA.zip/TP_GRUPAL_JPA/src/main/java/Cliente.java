import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Table
@SuperBuilder
@Getter
@Setter
public class Cliente extends AuditoriaApp {
    @Column(nullable = false)
    private String cuitCuil;

    @Column(nullable = false)
    private String denominacion;

    @OneToOne
    @JoinColumn(nullable = false, name = "id_contacto")
    private Contacto contacto;

    @OneToOne
    @JoinColumn(nullable = false, name = "id_domicilio")
    private Domicilio domicilio;
}